package com.xurong.ServiceTest;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.xurong.model.Books;
import com.xurong.service.BooksService;
@RunWith(SpringRunner.class)
@SpringBootTest
public class BooksServiceTest {
	@Autowired
	private BooksService booksService;
	@Test
	public void findAllBooksTest(){
		List<Books> books = booksService.findAllBooks();
		for(Books book : books){
			System.out.println(book.toString());
		}
	}

}
