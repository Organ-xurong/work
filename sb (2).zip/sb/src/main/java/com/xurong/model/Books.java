package com.xurong.model;

import java.util.Date;

public class Books {
    private String author;

    private String name;

    private String pages;

    private String price;

    private String publishtime;

    private Date completetime;

    private Date currenttime;

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author == null ? null : author.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPages() {
        return pages;
    }

    public void setPages(String pages) {
        this.pages = pages == null ? null : pages.trim();
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price == null ? null : price.trim();
    }

    public String getPublishtime() {
        return publishtime;
    }

    public void setPublishtime(String publishtime) {
        this.publishtime = publishtime == null ? null : publishtime.trim();
    }

    public Date getCompletetime() {
        return completetime;
    }

    public void setCompletetime(Date completetime) {
        this.completetime = completetime;
    }

    public Date getCurrenttime() {
        return currenttime;
    }

    public void setCurrenttime(Date currenttime) {
        this.currenttime = currenttime;
    }

	@Override
	public String toString() {
		return "Books [author=" + author + ", name=" + name + ", pages=" + pages + ", price=" + price + ", publishtime="
				+ publishtime + ", completetime=" + completetime + ", currenttime=" + currenttime + "]";
	}
    
}