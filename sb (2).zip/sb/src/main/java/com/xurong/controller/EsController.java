package com.xurong.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.xurong.common.Result;
import com.xurong.exception.MyException;
import com.xurong.utils.ResultUtil;

@RestController
@RequestMapping(value="/es")
public class EsController {
	private final static Logger logger = LoggerFactory.getLogger(EsController.class);
	@Autowired
	private TransportClient client;
	
	/**
	 * 根据id查询book
	 * @param id
	 * @return
	 */
	@GetMapping("/findById")
	public Result<Object> findBooks(String index,String type,@RequestParam(name="id",required=true)String id){
		try{
			if(id.isEmpty()){
				throw new Exception("id为空");
			}
			GetResponse result = this.client.prepareGet(index,type,id).get();
			if(result.isExists()){
				return ResultUtil.success(result.getSource());
			}else{
				return ResultUtil.success();
			}
		}catch(Exception e){
			logger.info("/findById--end:"+e.getMessage());
			e.printStackTrace();
			throw new MyException(e.getMessage());
		}
	}
	/**
	 * 添加文档
	 * @param name
	 * @param player
	 * @param startTime
	 * @return
	 */
	@PostMapping("/add/game")
	public Result<Object> addGame(String name,String player,
								@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")Date startTime){
		
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			XContentBuilder content = XContentFactory.jsonBuilder()
			.startObject();
			if(name!=null){
				content.field("NAME",name);
			}
			if(player!=null){
				content.field("PLAYER",player);
			}
			if(startTime!=null){
				content.field("STARTTIME",sdf.format(startTime));//startTime为date格式时，会默认转成时区格式
			}
			content.endObject();
			
			IndexResponse result = this.client.prepareIndex("fk","game").setSource(content).get();
			return ResultUtil.success(result.getId());
		}catch(Exception e){
			logger.info("/add/game--end:"+e.getMessage());
			e.printStackTrace();
			throw new MyException(e.getMessage());
		}
	}
	/**
	 * 删除文档
	 * @param index
	 * @param type
	 * @param id
	 * @return
	 */
	//DeleteMapping参数只能在url中传递
	@RequestMapping(value="/deleteById",method=RequestMethod.POST)
	public Result<Object> deleteById(String index,String type,String id){
		try{
			DeleteResponse result = this.client.prepareDelete(index,type,id).get();
			
			return ResultUtil.success(result.getResult());
		}catch(Exception e){
			logger.info("deleteById--end:"+e.getMessage());
			e.printStackTrace();
			throw new MyException(e.getMessage());
		}
		
	}
	/**
	 * 通过id更改文档
	 * @param index
	 * @param type
	 * @param id
	 * @param name
	 * @param player
	 * @return
	 */
	@PostMapping("/updateById")
	public Result<Object> updateById(String index,String type,String id,String name,String player){
		try{
			UpdateRequest update = new UpdateRequest(index,type,id);
			XContentBuilder content = XContentFactory.jsonBuilder().startObject();
			if(name!=null){
				content.field("NAME",name);
			}
			if(player!=null){
				content.field("PLAYER",player);
			}
			content.endObject();
			update.doc(content);
			UpdateResponse result = this.client.update(update).get();
			return ResultUtil.success(result.getResult());
		}catch(Exception e){
			logger.info("updateById--end:"+e.getMessage());
			e.printStackTrace();
			throw new MyException(e.getMessage());
		}
		
	}
	
	/**
	 * 复杂查询
	 * @param index
	 * @param type
	 * @param name
	 * @param player
	 * @param gtpages
	 * @param ltpages
	 * @return
	 */
	@PostMapping("/highQuery")
	public Result<Object> highQuery(String index,String type,String name,String player,Integer gtpages,Integer ltpages){
		
		try{
			
			BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
			if(name!=null){
				boolQuery.must(QueryBuilders.matchQuery("NAME", name));
			}
			if(player!=null){
				boolQuery.must(QueryBuilders.matchQuery("PLAYER", player));
			}
			//无需做空判断
			RangeQueryBuilder rangeQuery = QueryBuilders.rangeQuery("PAGES")
					.from(gtpages);
			if(ltpages!=null&&ltpages>0){
				rangeQuery.to(ltpages);
			}
			boolQuery.filter(rangeQuery);
			SearchRequestBuilder builder = this.client.prepareSearch(index)
					.setTypes(type)
					.setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
					.setQuery(boolQuery)
					.setFrom(0)
					.setSize(10);
			System.out.println(builder);
			SearchResponse response = builder.get();
			List<Map<String,Object>> result = new ArrayList<>();
			for(SearchHit hit : response.getHits()){
				result.add(hit.getSource());
			}
			return ResultUtil.success(result);
		}catch(Exception e){
			logger.info("highQuery--end:"+e.getMessage());
			e.printStackTrace();
			throw new MyException(e.getMessage());
		}
	}

}
