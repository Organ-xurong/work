package com.xurong.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xurong.common.Result;
import com.xurong.exception.MyException;
import com.xurong.service.UserService;
import com.xurong.service.impl.UserServiceImpl;
import com.xurong.utils.AuthUtil;
import com.xurong.utils.ResultUtil;

@RestController
public class UserController {
	private final static Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Resource
	private UserService userService;
	/**
	 * 登陆
	 * @param loginName
	 * @param request
	 * @return
	 */
	@RequestMapping("/login")
	public Result<Object> login(String loginName,HttpServletRequest request){
		try{
			String ticket = userService.login(loginName,request);
			logger.info("ticket={}",ticket);
			return ResultUtil.success(ticket);
		}catch (Exception e){
			throw new MyException("登陆失败："+e
					.getMessage());
		}
		
	}
	
	/**
	 * 登出
	 */
	@RequestMapping("/logonout")
	public Result<Object> logonout(String loginName,HttpServletRequest request){
		try{
			String ticket = AuthUtil.getTicket();
			userService.logonout(ticket);
			return ResultUtil.success();
		}catch(Exception e){
			throw new MyException("登出失败："+e.getMessage());
		}
	}

}
