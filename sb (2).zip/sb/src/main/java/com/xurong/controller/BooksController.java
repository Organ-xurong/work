package com.xurong.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xurong.common.Result;
import com.xurong.enums.ResultEnum;
import com.xurong.exception.MyException;
import com.xurong.model.Books;
import com.xurong.service.BooksService;
import com.xurong.utils.ResultUtil;

@RestController
public class BooksController{
	@Autowired
	private BooksService booksService;
	
	@RequestMapping(value="/findAllBooks")
	public Result<Object> findAllBooks(){
		return ResultUtil.success(booksService.findAllBooks());
	}
	@RequestMapping(value="/findOneBook")
	public Result<Object> findOneBook(Books books,Integer age){
		return ResultUtil.success(booksService.findOneBook(books));
	}

}
