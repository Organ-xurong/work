package com.xurong.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xurong.common.Result;
import com.xurong.utils.ResultUtil;


@ControllerAdvice
public class ExceptionHandle {

	@ExceptionHandler(value=Exception.class)
	@ResponseBody
	public Result handle(Exception e){
		if(e instanceof MyException){
			MyException exception = (MyException)e;
			return ResultUtil.error(exception.getCode(), exception.getMessage());
		}
		return ResultUtil.error(500, e.getMessage());
	}
}
