package com.xurong.utils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.xurong.common.Constants;

public class AuthUtil {

	public static HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) RequestContextHolder
                .getRequestAttributes()).getRequest();
    }
	
	public static HttpSession getSession() {
        return getRequest().getSession();
    }

    public static WebApplicationContext getWebApplicationContext() {
        return WebApplicationContextUtils
                .getWebApplicationContext(getRequest().getServletContext());
    }
    
	public static String getTicket(HttpServletRequest request) {
        String key = Constants.TICKET;
        String ticket = request.getParameter(key);
        if (ticket!=null&&!"".equals(ticket))
            return ticket;

        ticket = request.getHeader(key);
        if (ticket!=null&&!"".equals(ticket))
            return ticket;

        Cookie[] cookies = request.getCookies();
        if (cookies!=null&&cookies.length!=0) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(key)) {
                    ticket = cookie.getValue();
                    break;
                }
            }
        }
        if (ticket!=null&&!"".equals(ticket))
            return ticket;

        ticket = (String) request.getSession().getAttribute(ticket);
        if (ticket!=null&&!"".equals(ticket))
            return ticket;
        else
            return null;
    }
	
	public static String getTicket() {
        return getTicket(getRequest());
    }
}
