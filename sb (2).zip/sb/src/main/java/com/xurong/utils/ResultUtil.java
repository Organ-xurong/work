package com.xurong.utils;

import com.xurong.common.Result;

public class ResultUtil {

	public static Result<Object> success(Object obj){
		Result<Object> result = new Result<Object>();
		result.setCode(200);
		result.setMsg("操作成功");
		result.setData(obj);
		return result;
	}
	public static Result<Object> success(){
		return success(null);
	}
	public static Result<Object> error(Integer code,String msg){
		Result<Object> result = new Result<Object>();
		result.setCode(code);
		result.setMsg(msg);
		return result;
	}
	public static Result<Object> error(String msg){
		Result<Object> result = new Result<Object>();
		result.setCode(500);
		result.setMsg(msg);
		return result;
	}
	public static Result<Object> error(){
		Result<Object> result = new Result<Object>();
		result.setCode(500);
		result.setMsg("操作失败");
		return result;
	}
}
