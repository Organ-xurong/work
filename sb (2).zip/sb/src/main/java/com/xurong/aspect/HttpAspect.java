package com.xurong.aspect;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


@Aspect
@Component
public class HttpAspect {
	private final static Logger logger = LoggerFactory.getLogger(HttpAspect.class);
	
	/**
	 * 操作日志
	 */
	@Pointcut("execution(public com.xurong.common.Result com.xurong.controller.*Controller.*(..))")
	public void log(){}
	@Before("log()")
	public void doBefore(JoinPoint joinPoint){
		logger.info("doBefore============Start");
		ServletRequestAttributes attributes = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
		HttpServletRequest request = attributes.getRequest();
		
		logger.info("url={}",request.getRequestURL());
		
		logger.info("method={}",request.getMethod());
		
		logger.info("ip={}",request.getRemoteAddr());
		//类名+类方法
		logger.info("class_name={}",joinPoint.getSignature().getDeclaringTypeName()+"."+joinPoint.getSignature().getName());
		Object[] obj = joinPoint.getArgs();
		int i=0;
		for(Object o :obj){
			logger.info("args"+(i++)+"={}",o);
		}
		
		logger.info("doBefore=========end");
		
	}
	@After("log()")
	public void doAfter(){
		logger.info("doafter");
	}
	

}
