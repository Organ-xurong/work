package com.xurong.mapping;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.xurong.model.User;
@Mapper
public interface UserMapper {
    int insert(User record);

    int insertSelective(User record);
    
    User login(@Param(value="loginname")String loginname);
}