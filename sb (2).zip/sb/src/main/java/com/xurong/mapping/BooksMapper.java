package com.xurong.mapping;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.xurong.model.Books;
@Mapper
public interface BooksMapper {
    int insert(Books record);

    int insertSelective(Books record);

	List<Books> findAllBooks();

	Books findOneBook(Books books);
}