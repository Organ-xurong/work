package com.xurong.common;

public class Constants {

	public static final String TICKET = "ticket";
}
