package com.xurong.service;

import javax.servlet.http.HttpServletRequest;

import com.xurong.model.User;

public interface UserService {

	String login(String loginName,HttpServletRequest request);

	User auth(String ticket);

	void logonout(String ticket);
}
