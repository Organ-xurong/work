package com.xurong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xurong.mapping.BooksMapper;
import com.xurong.model.Books;
import com.xurong.service.BooksService;
@Service
public class BooksServiceImpl implements BooksService{

	@Autowired
	private BooksMapper booksMapper;
	
	public List<Books> findAllBooks(){
		return booksMapper.findAllBooks();
	}

	@Override
	public Books findOneBook(Books books) {
		// TODO Auto-generated method stub
		return booksMapper.findOneBook(books);
	}
}
