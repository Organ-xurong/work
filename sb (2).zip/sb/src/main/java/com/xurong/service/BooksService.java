package com.xurong.service;

import java.util.List;


import com.xurong.model.Books;


public interface BooksService {
	List<Books> findAllBooks();

	Books findOneBook(Books books);
	
}
