package com.xurong.service.impl;

import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.xurong.aspect.HttpAspect;
import com.xurong.enums.ResultEnum;
import com.xurong.exception.MyException;
import com.xurong.mapping.UserMapper;
import com.xurong.model.User;
import com.xurong.service.UserService;

import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
@Service
public class UserServiceImpl implements UserService{
	private final static Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	
	@Resource
    private EhCacheCacheManager cacheManager;
	@Resource
	private UserMapper userMapper;

	@Override
	public String login(String loginName,HttpServletRequest request) {
		// TODO Auto-generated method stub
		User user = userMapper.login(loginName);
		if(user==null){
			throw new MyException(ResultEnum.UNKOWN_ERROT);
		}else{
			String clientIp = request.getRemoteAddr();//获取客户端IP
	        String clientUserAgent = request.getHeader("user-agent");//获取客户端浏览器信息
	        String clientInfo = clientIp + clientUserAgent;
	        /**
	         * 同一浏览器只有一个凭证
	         */
	        Cache cache = cacheManager.getCache("loginUserCache");
	        Ehcache mEhcache = (Ehcache)cache.getNativeCache();
	        if (mEhcache.isValueInCache(clientInfo)||mEhcache.isValueInCache(loginName)) {//清除同一客户端上的历史登录用户
	            List<Object> cacheKeyList = mEhcache.getKeysWithExpiryCheck();
	            for (Object  cacheKey: cacheKeyList) {
	                Element cacheValueEle = mEhcache.get(cacheKey);
	                Object cacheValue = cacheValueEle.getObjectValue();
	                if (clientInfo.equals(String.valueOf(cacheValue))||loginName.equals(String.valueOf(cacheValue))) {
	                    String cacheKeyClient = String.valueOf(cacheKey);
	                    String cacheKeyTicket = cacheKeyClient;
	                    if(cacheKeyClient.indexOf("clientInfo")>0){
	                    	cacheKeyTicket = cacheKeyClient.substring(0, cacheKeyClient.indexOf("clientInfo"));
	                    }
	                    
	                    logger.info("============1===========");
	                    logger.info("cacheKeyClient: " + cacheKeyClient);
	                    logger.info("cacheKeyTicket: " + cacheKeyTicket);
	                    cache.evict(cacheKeyClient);
	                    cache.evict(cacheKeyTicket);
	                    logger.info("============2===========");
	                    break;
	                }
	            }
	        }

	        String ticket = UUID.randomUUID().toString();
	        cache.put(ticket, user.getLoginname());
	        cache.put(ticket + "clientInfo", clientInfo);
	        
	        return ticket;
		}
		
	}

	/**
	 * 权限认证获取user
	 */
	@Override
	public User auth(String ticket) {
		// TODO Auto-generated method stub
		User user = getByTicket(ticket);

        if (user == null) {
            throw new MyException(ResultEnum.AUTH_ERROR);
        }
        return user;
	}

	private User getByTicket(String ticket) {
		// TODO Auto-generated method stub
		if(ticket==null||"".equals(ticket)){
			throw new MyException(ResultEnum.AUTH_ERROR);
		}
		Cache cache = cacheManager.getCache("loginUserCache");
        Cache.ValueWrapper cvw = cache.get(ticket);
        if (null != cvw) {
            String loginName = (String)cvw.get();
            User userObj = userMapper.login(loginName);
            return userObj;
        }
        return null;
	}

	@Override
	public void logonout(String ticket) {
		// TODO Auto-generated method stub
		if (StringUtils.isEmpty(ticket))
            return;
		Cache cache = cacheManager.getCache("loginUserCache");
        cache.evict(ticket);
        cache.evict(ticket + "clientInfo");
	}

}
