package com.xurong.enums;

public enum ResultEnum {
	
	UNKOWN_ERROT(500,"服务器错误"),
	SUCCESS(200,"操作成功"),
	AUTH_ERROR(501,"权限验证错误")
	;
	private Integer code;
	private String msg;
	private ResultEnum(Integer code, String msg) {
		this.code = code;
		this.msg = msg;
	}
	public Integer getCode() {
		return code;
	}
	public String getMsg() {
		return msg;
	}
	
	
}
